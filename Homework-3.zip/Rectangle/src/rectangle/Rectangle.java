package rectangle;

public class Rectangle {
	private double a;
	private double b;

	public void setWidth(double a) {
		this.a = a;
	}
	public void setHeight(double b) {
		this.b = b;
	}
	
	protected double computeArea() {
		return this.a * this.b;
	}
	
	protected double computePerimeter() {
		return (this.a + this.b)*2;
	}
	public int compare(Rectangle rectangle1) {
		if(rectangle1.computeArea() > this.computeArea()) {
			return 1;
		}else if(rectangle1.computeArea() < this.computeArea()) {
			return -1;
		}else {
			return 0;
		}
	}
}


