package childRectangle;

public class Rectangle {
	private double a;
	private double b;

	public void setWidth(double a) {
		this.a = a;
	}
	public void setHeight(double b) {
		this.b = b;
	}
	
	protected double computePerimeter() {
		return (this.a + this.b)*2;
	}
	
	public int compareTwoRect(Rectangle rectangle2, Rectangle rectangle4) {
		if(rectangle2.computePerimeter() > rectangle4.computePerimeter()) {
			return 1;
		}else if(rectangle2.computePerimeter() < rectangle4.computePerimeter()) {
			return -1;
		}else {
			return 0;
		}
	}
}

