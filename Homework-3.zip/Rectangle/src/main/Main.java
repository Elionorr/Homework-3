package main;

import rectangle.Rectangle;

public class Main {

	public static void main(String[] args) {
		rectangle.Rectangle rectangle1 = new Rectangle();
		rectangle1.setWidth(10);
		rectangle1.setHeight(10);
		
		
		rectangle.Rectangle rectangle2 = new Rectangle(); 
		rectangle2.setWidth(10);
		rectangle2.setHeight(10);
		
		
	    childRectangle.Rectangle rectangle3 = new  childRectangle.Rectangle();
	    rectangle3.setWidth(2);
	    rectangle3.setHeight(6);
		
	    childRectangle.Rectangle rectangle4 = new  childRectangle.Rectangle();
	    rectangle4.setWidth(10);
	    rectangle4.setHeight(5);
	    
	    
	    System.out.println("Comparison by areas: " + rectangle1.compare(rectangle2));
        System.out.println("Comparison by perimeters: " + rectangle3.compareTwoRect(rectangle3, rectangle4));
	}

}
